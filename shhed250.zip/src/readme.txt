

       "SHH ED" er helt gratis. Det eneste som kreves hvis du velger �
       bruke programmet, er at du skriver og registrerer deg som bruker.

       P� den m�ten f�r jeg en viss oversikt over hvilke av mine programmer
       som brukes, og jeg f�r ogs� mulighet til � kontakte brukere hvis det
       oppst�r problemer av noe slag.

       Dette gjelder ogs� hvis du f�r programmet gjennom en sharewarefor-
       handler. Jeg har ingen kontinuerlig kontakt med disse firmaene, s�
       opplysninger du sender til dem, kommer sjelden til meg.



       Det jeg �nsker � vite er:


           Navn
           Adresse
           Telefon

           Hvor du fikk programmet fra

           Programmets versjon

           Evt. hvilke andre av mine programmer du bruker



       Min adresse finner du i filen ED.DOC, sammen med en beskrivelse av
       programmet.



                                                        Takk for det,


                                                        Sverre.

